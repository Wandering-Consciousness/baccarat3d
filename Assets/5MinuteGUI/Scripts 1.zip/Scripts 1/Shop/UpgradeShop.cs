using UnityEngine;
using System.Collections;

public class UpgradeShop : BaseMenuState {
	public Rect startRect = new Rect(.5f,.2f,.45f,.6f);
	public string shopID = "Gold Shop";
	public GUISkin guiSKin0;
	public ShopItem[] items;
	void Start () {
//		m_items = gameObject.GetComponentsInChildren<GUIItem>();
	}
	
	void OnGUI()
	{
		float mx = transform.position.x;
		float my = transform.position.y;
		
			GUI.skin = guiSKin0;
		Rect r = startRect;
		r.x+=mx;
		r.y+=my;
		//r.y += 0.05f;
		GUI.Box(GUIHelper.screenRect(r),shopID + "\nGold:" + PlayerPrefs.GetInt("TOTAL_SCORE",0));
		float x0 = r.x;
		r.y += 0.1f;
		for(int i=0; i<items.Length; i++)
		{
			r.x = x0;
			r = items[i].onGUI(r);
			
		}
	}
}
