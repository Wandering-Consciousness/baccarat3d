using UnityEngine;
using System.Collections;

[System.Serializable]
public class BaseItem  {
	public int initalLevel = 0;
	public int initalCost = 0;
	
	public int baseCost 	= 	100;
	
	public string shopID;
	public int maxLevel	=	5;	
	public int minVal=1;
	public int offset = 3;


	
	
	public void Start()
	{

		
	}
	void onPressCBF(string id)
	{
		if(id.Equals("buy"))
		{
			attemptUpgrade();
		}
	}
	protected virtual void attemptUpgrade()
	{
		int curGold = PlayerPrefs.GetInt("TOTAL_SCORE",0);
		if(upgradeSpell(ref curGold))
		{
			PlayerPrefs.SetInt("TOTAL_SCORE",curGold);
		}		
	}
	public virtual void Update ()
	{

//		setUpgradeLevelText( (getCurrentLevel()).ToString() );
	//	setExtraText( ((getCurrentLevel()) * 50).ToString() );
		
		if(getCurrentLevel()==maxLevel)
		{
		//	setUpgradeCostText("");
		////	setUpgradeLevelText(getCurrentLevel().ToString() + " Max");
		}else{
		//	setUpgradeCostText(getGoldCost().ToString());
			
		}

	}
	/*
	void setUpgradeCostText(string str)
	{
		if(costGT)
		{
			costGT.text = costPrefix + str;
			if(str.Equals(""))
			{
				costGT.text ="";
			}
		}
	}
	void setUpgradeLevelText(string str)
	{
		if(levelGT)
		{
			levelGT.text = levelPrefix+ str;
		}
	}
	*/
	
	public bool upgradeSpell(ref int gold)
	{
		int currentLevel = getCurrentLevel();
		bool canUpgrade = false;
		int goldCost = getGoldCost();
		if(currentLevel < maxLevel && gold>=goldCost)
		{
			currentLevel++;
			
			setLevel(  currentLevel);
			
			gold -= goldCost;
			canUpgrade = true;
		}
		return canUpgrade;
	}
	
	public virtual int getCurrentLevel()
	{
		int val = Mathf.Clamp(PlayerPrefs.GetInt(shopID,0),minVal,maxLevel);
		return val;
	}
	
	public virtual void setLevel(int levelID)
	{

		PlayerPrefs.SetInt(shopID,levelID);
	}
	
	public int getGoldCost()
	{
		int m = (getCurrentLevel()-1) + initalLevel;
		int n = (int)Mathf.Pow(2,m);
		n--;
//		Debug.Log ("m + " + m + "n " + n);
		int cost = initalCost + (n * baseCost);

		return cost;
	}
	
	public int getMaxLevel()
	{
		return maxLevel;
	}

}
