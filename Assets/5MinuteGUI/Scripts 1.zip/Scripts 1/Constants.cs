#define MY_IPHONE_BUILD
using UnityEngine;
using System.Collections;

public class Constants
{

	
	//the name of the URL which will hold the highscores php
	public static string baseURL 	= "http://inanegames.ca/miniPutt/highscores.php"; 
	
	//the name of hte table to use.
	public static string tableName 	= "GatsbyScores"; 
	
	public static string CNST_MUSIC = "Music";
	public static string CNST_SFX = "SFX";
	public static string CNST_PRACTICE_MODE = "SFX";
	public static string CNST_COURSE_INDEX = "CourseIndex";
	public static string CNST_LAST_SCENE = "LAST_SCENE";
	public static string CNST_SLIDER = "GG_SLIDE_SCALARX3";
	
	public static void setHighscore(string id, int highscore)
	{
		PlayerPrefs.SetInt(id,highscore);		
	}
	public static int getHighscore(string id)
	{
		return PlayerPrefs.GetInt(id);
		
	}
	

	
	
	public static Vector2 getScreenScalar()
	{
		float scalarX = .5f;
		float scalarY = .5f;
		if(Screen.width > 480)
		{
			scalarX=1f;
			scalarY=1f;
		}
		if(Screen.width > 1024)
		{
		//	scalarX = Screen.width / 1024f;
		//	scalarY = Screen.height / 768f;
		}
		//Debug.Log("scalarX"+scalarX+ " scalarY" + scalarY);
		return new Vector2(scalarX,scalarY);
	}

	public static bool getBool(string id, bool defaultVal)
	{
		return PlayerPrefs.GetInt( id,defaultVal ? 1 : 0 ) == 1;
	}
	public static void setBool(string id, bool val)
	{
		PlayerPrefs.SetInt( id, val ? 1 : 0);
	}


	public static void setLookAtPost(bool lookAtPost)
	{
		PlayerPrefs.SetInt("LookAtPost", lookAtPost ? 0 : 1);
	}
	

	
}
