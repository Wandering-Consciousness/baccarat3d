using UnityEngine;
using System.Collections;

public class BaseMenuState : MonoBehaviour {
	private float m_moveTime = 0;
	public float moveTime = .5f;
	public Vector3 startPos = new Vector3(-1,0,0);
	public Vector3 endPos = new Vector3(0,0,0);
	protected bool m_done = true;
	
	private float m_dir = 1;
	private int m_cmd;
	public void swapObjects(GameObject go, int cmd=-1)
	{
		m_cmd = cmd;
		if(go)
		{
			go.SetActive(true);
		}
		if(gameObject)
		{
			gameObject.SendMessage("disable",-1);		
		}
	}
	public virtual  void onDone(float dir, int id)
	{	
		if(m_dir==-1)
		{
			gameObject.SetActive(false);
		}
		
	}
	
	void LateUpdate()
	{
		if(m_done==false)
		{
			float v = Time.realtimeSinceStartup - m_moveTime;
			float val = v / moveTime;
//			Debug.Log("v" + v + " m_moveTime "  + m_moveTime + " Time.realtimeSinceStartup " + Time.realtimeSinceStartup);
			if(val>1 )
			{
				val = 1;
				m_done = true;
				onDone (m_dir,m_cmd);
			}
			if(m_dir>0)
			{
				transform.position = Vector3.Lerp(startPos,endPos,val);
			}else{
				transform.position = Vector3.Lerp(endPos,startPos,val);
			}
		}
	}
	public void disable(int cmd=-1)
	{
		//if(m_done)
		{
			m_cmd = cmd;
			m_done = false;
			m_moveTime = 0 + Time.realtimeSinceStartup;
			m_dir=-1;
			transform.position = endPos;
		}
	}
	public virtual void OnEnable()
	{
		if(m_done)
		{
			m_dir=1;
			m_done = false;
			m_moveTime=0;
			if(Time.time>0.1f)
			{
				m_moveTime = Time.realtimeSinceStartup; 
			}
//			Debug.Log (" onEnable m_moveTime " + m_moveTime);
			transform.position = startPos;
		}
	}
}
