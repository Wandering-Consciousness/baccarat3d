using UnityEngine;
using System.Collections;

public class MenuConstants
{
	//our default x offset
	public static float OFFSET_X = 0.05f;
	
	//out default y offset
	public static float OFFSET_Y = 0.1f;
	
	
	
}
